<?php

namespace App\Http\Controllers\Pos;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Staff;
use Auth;
use Illuminate\Support\Carbon;

class StaffController extends Controller
{
    public function StaffAll(){
        // $students = Student::all();
        $staffs = Staff::latest()->get();
        return view('backend.staff.staff_all',compact('staffs'));
    } //End Method

    public function StaffAdd(){
        return view('backend.staff.staff_add');
    }//End Method

    public function StaffStore(Request $request){

        Staff::insert([
            'name' => $request->name,
            'staff_no' => $request->staff_no,
            'email' => $request->email,
            'created_by' => Auth::user()->id,
            'created_at' => Carbon::now(),
    ]);
        $notification = array(
            'message' => 'Staff Added Successfully', 
            'alert-type' => 'success'
        );

        return redirect()->route('staff.all')->with($notification);
    } // End Method 


     public function StaffEdit($id){

        $staff = Staff::findOrFail($id);
        return view('backend.staff.staff_edit',compact('staff'));

    }//End Method

     public function StaffUpdate(Request $request){

        $staff_id = $request->id;

        Student::findOrFail($staff_id)->update([
            'name' => $request->name,
            'staff_no' => $request->staff_no,
            'email' => $request->email,
            'updated_by' => Auth::user()->id,
            'updated_at' => Carbon::now(),
           
    ]); 

        $notification = array(
            'message' => 'Staff Updated Successfully', 
            'alert-type' => 'success'
        );

        return redirect()->route('staff.all')->with($notification);
    } // End Method 

    public function StaffDelete($id){
        Staff::findOrFail($id)->delete();
        $notification = array(
            'message' => 'Staff Deleted Successfully', 
            'alert-type' => 'success'
        );
        return redirect()->back()->with($notification);

    }// End Method 
}
