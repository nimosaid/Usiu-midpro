<?php

namespace App\Http\Controllers\Pos;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Student;
use Auth;
use Illuminate\Support\Carbon;

class StudentController extends Controller
{
    public function StudentAll(){
        // $students = Student::all();
        $students = Student::latest()->get();
        return view('backend.student.student_all',compact('students'));
    } //End Method

    public function StudentAdd(){
        return view('backend.student.student_add');
    }//End Method

    public function StudentStore(Request $request){

        Student::insert([
            'name' => $request->name,
            'admission_no' => $request->admission_no,
            'email' => $request->email,
            'created_by' => Auth::user()->id,
            'created_at' => Carbon::now(),
    ]);
        $notification = array(
            'message' => 'Student Added Successfully', 
            'alert-type' => 'success'
        );

        return redirect()->route('student.all')->with($notification);
    } // End Method 

     public function StudentEdit($id){

        $student = Student::findOrFail($id);
        return view('backend.student.student_edit',compact('student'));

    }//End Method

     public function StudentUpdate(Request $request){

        $student_id = $request->id;

        Student::findOrFail($student_id)->update([
            'name' => $request->name,
            'admission_no' => $request->admission_no,
            'email' => $request->email,
            'updated_by' => Auth::user()->id,
            'updated_at' => Carbon::now(),
           
    ]); 

        $notification = array(
            'message' => 'Student Updated Successfully', 
            'alert-type' => 'success'
        );

        return redirect()->route('student.all')->with($notification);
    } // End Method 

    public function StudentDelete($id){
        Student::findOrFail($id)->delete();
        $notification = array(
            'message' => 'Student Deleted Successfully', 
            'alert-type' => 'success'
        );
        return redirect()->back()->with($notification);

    }// End Method 

}    





