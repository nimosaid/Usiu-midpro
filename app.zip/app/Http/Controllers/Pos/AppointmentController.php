<?php

namespace App\Http\Controllers\Pos;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Appointment;
use App\Models\Department;
use App\Models\Staff;
use Auth;
use Illuminate\Support\Carbon;

class AppointmentController extends Controller
{
    public function AppointmentAll(){
        $allData = Appointment::orderBy('date','desc')->orderBy('id','desc');
        return view('backend.appointment.appointment_all',compact('allData'));

    }//End method

    public function AppointmentAdd(){

        $staffs = Staff::all();
        $departments = Department::all();
        return view('backend.appointment.appointment_add',compact('departments','staffs'));

    }//End method

}
