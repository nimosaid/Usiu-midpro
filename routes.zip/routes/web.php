<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Demo\DemoController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\Pos\StudentController;
use App\Http\Controllers\Pos\DepartmentController;
use App\Http\Controllers\Pos\StaffController;
use App\Http\Controllers\Pos\AppointmentController;


Route::get('/', function () {
    return view('welcome');
});


Route::controller(DemoController::class)->group(function () {
    Route::get('/about', 'Index')->name('about.page')->middleware('check');
    Route::get('/contact', 'ContactMethod')->name('cotact.page');
    ;
});


 // Admin All Route 
Route::controller(AdminController::class)->group(function () {
    Route::get('/admin/logout', 'destroy')->name('admin.logout');
    Route::get('/admin/profile', 'Profile')->name('admin.profile');
    Route::get('/edit/profile', 'EditProfile')->name('edit.profile');
    Route::post('/store/profile', 'StoreProfile')->name('store.profile');

    Route::get('/change/password', 'ChangePassword')->name('change.password');
    Route::post('/update/password', 'UpdatePassword')->name('update.password');
     
});

//  // Staff All Route 
Route::controller(StaffController::class)->group(function () {
    Route::get('/staff/all', 'StaffAll')->name('staff.all');
    Route::get('/staff/add', 'StaffAdd')->name('staff.add');
    Route::post('/staff/store', 'StaffStore')->name('staff.store');
    Route::get('/staff/edit{id}', 'StaffEdit')->name('staff.edit');
    Route::post('/staff/update', 'StaffUpdate')->name('staff.update');
    Route::get('/staff/delete{id}', 'StaffDelete')->name('staff.delete');

});

// Student All Route 
Route::controller(StudentController::class)->group(function () {
    Route::get('/student/all', 'StudentAll')->name('student.all');
    Route::get('/student/add', 'StudentAdd')->name('student.add');
    Route::post('/student/store', 'StudentStore')->name('student.store');
    Route::get('/student/edit{id}', 'StudentEdit')->name('student.edit');
    Route::post('/student/update', 'StudentUpdate')->name('student.update');
    Route::get('/student/delete{id}', 'StudentDelete')->name('student.delete');  
});

// Department All Route 
Route::controller(DepartmentController::class)->group(function () {
    Route::get('/department/all', 'DepartmentAll')->name('department.all');
    Route::get('/department/add', 'DepartmentAdd')->name('department.add');
    Route::post('/department/store', 'DepartmentStore')->name('department.store');
    Route::get('/department/edit{id}', 'DepartmentEdit')->name('department.edit');
    Route::post('/department/update', 'DepartmentUpdate')->name('department.update');
    Route::get('/department/delete{id}', 'DepartmentDelete')->name('department.delete');

});

// // Appointment All Route 
Route::controller(AppointmentController::class)->group(function () {
    Route::get('/appointment/all', 'AppointmentAll')->name('appointment.all');
    Route::get('/appointment/add', 'AppointmentAdd')->name('appointment.add');
    // Route::get('/appointment/delete{id}', 'AppointmentDelete')->name('appointment.delete');

    

     
});


Route::get('/dashboard', function () {
    return view('admin.index');
})->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';


// Route::get('/contact', function () {
//     return view('contact');
// });
