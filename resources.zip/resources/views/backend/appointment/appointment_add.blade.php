@extends('admin.admin_master')
@section('admin')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 

<div class="page-content">
<div class="container-fluid">

<div class="row">
<div class="col-12">
    <div class="card">
        <div class="card-body">

            <h4 class="card-title">Add Appointment Page </h4><br><br>

    <div class="row">
        <div class="col-md-4">
            <div class="md-3">
                <label for="example-text-input" class="form-label">Date</label>
                <input class="form-control example-date-input"  name="date" type="date"  id="date" >
                </div>
            </div>
            <!-- end row -->
<br>
<br>
            <div class="col-md-4">
            <div class="md-3">
                <label for="example-text-input" class="form-label">Staff</label>
                <select id="staff_no " name="staff_no">
                    <option selected="">Open this select menu</option>
                    <option selected="">Nimo</option>
                    <option selected="">Jamil</option>
                </select>
                </div>
            </div>

            <div class="col-md-4">
            <div class="md-3">
                <label for="example-text-input" class="form-label">Department</label>
                <select id="departments_name " name="departments_name">
                    <option selected="">Open this select menu</option>
                    <option selected="">IT Services</option>
                    <option selected="">Counselling center</option>
                    <option selected="">Career Service</option>
                    <option selected="">Course Advisor</option>
                </select>
                
            </div>

            <div class="col-md-4">
                <div class="md-3">
                    <label for="example-text-input" class="form-label" style="margin-top: 40px;"></label>
                    <input type="submit"  class="btn btn-secondary btn-rounded waves-effect waves-light" value="Add">
                </div>
            </div>

           
            </div>
        </div>
        
    </div>
             
           
           
        </div>
        <!-- //End Card Body -->
    </div>
</div> <!-- end col -->
</div>
 


</div>
</div>



 
@endsection 
