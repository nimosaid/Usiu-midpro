<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Contact Page</title>
</head>
<body>
	<h2> This is a Contact Page from controller </h2>
	<a href="{{ route('about.page') }}"> About </a>
</body>
</html>